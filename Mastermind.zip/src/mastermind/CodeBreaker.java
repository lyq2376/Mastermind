package mastermind;
import java.util.Scanner;

/**
 *  file: CodeBreaker.java
 *  User class for cracking secret code from CodeMaker
 *  language: Java
 *  author: Lindy Quach
 *  email: lyq2376@rit.edu
 *  section: 1 (Group A)
 */


public class CodeBreaker {
    /** Initialize scanner **/
    Scanner sc = new Scanner(System.in);
    /** Initialize quit command **/
    private final static char QUIT = 'q';
    /** Initialize score **/
    private int score;

    /**
     * Set score to 0
     */
    public CodeBreaker(){
        this.score = 0;
    }
    /**
     * Check guess to see if it's valid
     * @return null if not valid
     * @return guess if valid
     */
    public Guess getGuess(){
            String guess = sc.nextLine();
            System.out.println("? " + guess);
        if ( guess.equals(String.valueOf(QUIT))) {
            System.out.println("Exiting Mastermind");
            System.exit(0);
        } else if ( guess.length() != 4) {
            System.out.println("Guess must have 4 digits!");
            return null;
        } else if (!(MasterMind.codeInRange( guess)))
        {
            System.out.println("Guess must have all digits between 1 and 8!");
            return null;
        } else if (!(MasterMind.codeNoDuplicates( guess) ))
        {
            System.out.println(" Guess cannot have duplicate digits!");
            return null;
        }
        return new Guess(guess);
    }

    /**
     * Ending score when game is over
     * @return Score
     */
    public int getScore(){
        return this.score;
    }

    /**
     * Add amount to score using methods from CodeMaker
     * Specific methods are countCorrectPosition and countWrongPosition
     * @param amount
     */
    public void increaseScore(int amount){
        this.score = this.score + amount;
    }

}
