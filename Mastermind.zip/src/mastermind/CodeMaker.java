package mastermind;
/**
 * file: CodeMaker.java
 * The class CodeMaker compares the guess along with the secret code
 * Updates the current number of correct and wrong positions
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class CodeMaker{
    /** Secret code **/
    private String code;

    /**
     * Updates the secret code
     * @param secretCode
     */
    public CodeMaker(String secretCode){
        this.code = secretCode;
    }

    /**
     * Updates the current number of correct and wrong positions
     * @param guess
     */
    public void checkGuess(Guess guess){
        guess.setCorrectPositions(countCorrectPosition(guess));
        guess.setWrongPositions(countWrongPosition(guess));
    }

    /**
     * Counts the number of correct positions
     * @rit.pre g is a 4 digits string
     * @param g
     * @return number of correct positions
     */
    public int countCorrectPosition(Guess g){
        int count = 0;
        for(int i = 0; i < g.getGuess().length(); ++i){
            if(g.getGuess().charAt(i) == this.code.charAt(i)){
                count+=1;
            }
        }
        return count;
    }
    /**
     * Counts the number of wrong positions
     * @rit.pre g is a 4 digits string
     * @param g
     * @return number of wrong positions
     */
    public int countWrongPosition(Guess g){
        int count = 0;
        for (int i = 0; i < g.getGuess().length(); ++i){
            for(int j = 0; j < this.code.length(); ++j){
                if(g.getGuess().charAt(i) == this.code.charAt(j)){
                    count+=1;
                }
            }
        }
        return count - countCorrectPosition(g);
    }
    /**
     * @return secret code
     */
    public String getSecretCode() {
        return this.code;
    }
}
