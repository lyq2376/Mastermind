package mastermind;
/**
 * file: Guess.java
 * The class Guess is a 4 digit guess in the Mastermind game.
 * It will be replaced by the new Guess from CodeBreaker.
 * CodeMaker will check the guess for correct and wrong positions.
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class Guess {
    /** the new 4 digit guess string */
    private String myGuess;
    /** number of wrong positions */
    private int wrongPosition;
    /** original guess number */
    private static int guessNum = 1;
    /** number of correct positions */
    private int correctPosition;
    /** current guess number */
    private int id;

    /**
     * Update the myGuess string to the guess object
     * Set wrong and correct positions to 0
     * Set id to the current guess number
     * Original guess number will increase by 1
     * @param guess
     * @rit.pre guess is a 4 digit string
     */
    public Guess(String guess) {
        this.myGuess = guess;
        this.wrongPosition = 0;
        this.correctPosition = 0;
        this.id = guessNum;
        guessNum++;

    }

    /**
     * Set the amount of correctPositions to a specific number
     * The parameter is obtained by the countCorrectPositions
     * in Code Maker.
     * @param correctPositions
     */
    public void setCorrectPositions(int correctPositions) {
        this.correctPosition = correctPositions;
    }

    /**
     * @return current number of correct positions
     */
    public int getCorrectPositions() {
        return this.correctPosition;
    }

    /**
     * Set the amount of wrongPositions to a specific number
     * The parameter is obtained by the countWrongPositions
     * in Code Maker.
     * @param wrongPositions
     */
    public void setWrongPositions(int wrongPositions){
        this.wrongPosition = wrongPositions;
    }

    /**
     * @return current number of wrong positions
     */
    public int getWrongPositions(){
        return this.wrongPosition;
    }

    /**
     * Comparing otherGuess and other are the same through
     * wrong and correct positions, guess numbers, and strings
     * @rit.pre guess and other are 4 digit strings
     * @param other, guess object
     * @return True if guess and other are equal and False if not
     */
    public boolean equals(Object other){
        if(other instanceof Guess otherGuess) {
            return otherGuess.wrongPosition == this.wrongPosition &&
                    otherGuess.correctPosition == this.correctPosition &&
                    otherGuess.id == this.id &&
                    otherGuess.myGuess.equals(this.myGuess);
        }
        else {
            return false;
        }
    }

    /**
     * @return guess
     */
    public String getGuess(){
        return this.myGuess;
    }

    /**
     * Create a string containing guess number, guess, correct and wrong
     * positions
     * @return string showing guess number, guess, correct and wrong
     * positions
     */
    @Override
    public String toString() {
        return "Guess #" + this.id + ": " + getGuess()
                + " (B:" + getCorrectPositions() + " W:" + getWrongPositions() + ")";
    }
}
