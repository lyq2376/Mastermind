package mastermind;

import java.util.ArrayList;
/**
 * file: Guesses.java
 * The class Guesses create a list of Guesses
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */

public class Guesses {
    /** List of Guesses **/
    private ArrayList<Guess> guessList = new ArrayList<Guess>();
    /**
     * Updating the list of Guesses
     * **/
    public Guesses(){
        this.guessList = new ArrayList<>();
    }

    /**
     * Add a guess to the list of guesses
     * @rit.pre guess is a 4 digit string
     * @param guess
     */
    public void addGuess(Guess guess){
        this.guessList.add(guess);
    }

    /**
     * Print out the list of guesses
     */
    public void displayGuesses(){
        for(int i = 0; i < this.guessList.size(); ++i){
            System.out.println(this.guessList.get(i));
        }
    }
}
